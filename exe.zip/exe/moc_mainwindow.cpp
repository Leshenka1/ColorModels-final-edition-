/****************************************************************************
** Meta object code from reading C++ file 'mainwindow.h'
**
** Created by: The Qt Meta Object Compiler version 67 (Qt 5.14.2)
**
** WARNING! All changes made in this file will be lost!
*****************************************************************************/

#include <memory>
#include "../../ColorModels/mainwindow.h"
#include <QtCore/qbytearray.h>
#include <QtCore/qmetatype.h>
#if !defined(Q_MOC_OUTPUT_REVISION)
#error "The header file 'mainwindow.h' doesn't include <QObject>."
#elif Q_MOC_OUTPUT_REVISION != 67
#error "This file was generated using the moc from 5.14.2. It"
#error "cannot be used with the include files from this version of Qt."
#error "(The moc has changed too much.)"
#endif

QT_BEGIN_MOC_NAMESPACE
QT_WARNING_PUSH
QT_WARNING_DISABLE_DEPRECATED
struct qt_meta_stringdata_MainWindow_t {
    QByteArrayData data[33];
    char stringdata0[855];
};
#define QT_MOC_LITERAL(idx, ofs, len) \
    Q_STATIC_BYTE_ARRAY_DATA_HEADER_INITIALIZER_WITH_OFFSET(len, \
    qptrdiff(offsetof(qt_meta_stringdata_MainWindow_t, stringdata0) + ofs \
        - idx * sizeof(QByteArrayData)) \
    )
static const qt_meta_stringdata_MainWindow_t qt_meta_stringdata_MainWindow = {
    {
QT_MOC_LITERAL(0, 0, 10), // "MainWindow"
QT_MOC_LITERAL(1, 11, 21), // "on_DrawButton_clicked"
QT_MOC_LITERAL(2, 33, 0), // ""
QT_MOC_LITERAL(3, 34, 22), // "on_comboBox1_activated"
QT_MOC_LITERAL(4, 57, 5), // "index"
QT_MOC_LITERAL(5, 63, 22), // "on_comboBox2_activated"
QT_MOC_LITERAL(6, 86, 22), // "on_comboBox3_activated"
QT_MOC_LITERAL(7, 109, 25), // "on_lineEdit_1_textChanged"
QT_MOC_LITERAL(8, 135, 4), // "arg1"
QT_MOC_LITERAL(9, 140, 25), // "on_lineEdit_2_textChanged"
QT_MOC_LITERAL(10, 166, 25), // "on_lineEdit_3_textChanged"
QT_MOC_LITERAL(11, 192, 25), // "on_lineEdit_4_textChanged"
QT_MOC_LITERAL(12, 218, 25), // "on_lineEdit_5_textChanged"
QT_MOC_LITERAL(13, 244, 25), // "on_lineEdit_6_textChanged"
QT_MOC_LITERAL(14, 270, 25), // "on_lineEdit_7_textChanged"
QT_MOC_LITERAL(15, 296, 25), // "on_lineEdit_8_textChanged"
QT_MOC_LITERAL(16, 322, 25), // "on_lineEdit_9_textChanged"
QT_MOC_LITERAL(17, 348, 27), // "on_lineEdit_1_4_textChanged"
QT_MOC_LITERAL(18, 376, 27), // "on_lineEdit_2_4_textChanged"
QT_MOC_LITERAL(19, 404, 27), // "on_lineEdit_3_4_textChanged"
QT_MOC_LITERAL(20, 432, 33), // "on_horizontalSlider_1_sliderM..."
QT_MOC_LITERAL(21, 466, 8), // "position"
QT_MOC_LITERAL(22, 475, 33), // "on_horizontalSlider_2_sliderM..."
QT_MOC_LITERAL(23, 509, 33), // "on_horizontalSlider_3_sliderM..."
QT_MOC_LITERAL(24, 543, 33), // "on_horizontalSlider_4_sliderM..."
QT_MOC_LITERAL(25, 577, 33), // "on_horizontalSlider_5_sliderM..."
QT_MOC_LITERAL(26, 611, 33), // "on_horizontalSlider_6_sliderM..."
QT_MOC_LITERAL(27, 645, 33), // "on_horizontalSlider_7_sliderM..."
QT_MOC_LITERAL(28, 679, 33), // "on_horizontalSlider_8_sliderM..."
QT_MOC_LITERAL(29, 713, 33), // "on_horizontalSlider_9_sliderM..."
QT_MOC_LITERAL(30, 747, 35), // "on_horizontalSlider_1_4_slide..."
QT_MOC_LITERAL(31, 783, 35), // "on_horizontalSlider_2_4_slide..."
QT_MOC_LITERAL(32, 819, 35) // "on_horizontalSlider_3_4_slide..."

    },
    "MainWindow\0on_DrawButton_clicked\0\0"
    "on_comboBox1_activated\0index\0"
    "on_comboBox2_activated\0on_comboBox3_activated\0"
    "on_lineEdit_1_textChanged\0arg1\0"
    "on_lineEdit_2_textChanged\0"
    "on_lineEdit_3_textChanged\0"
    "on_lineEdit_4_textChanged\0"
    "on_lineEdit_5_textChanged\0"
    "on_lineEdit_6_textChanged\0"
    "on_lineEdit_7_textChanged\0"
    "on_lineEdit_8_textChanged\0"
    "on_lineEdit_9_textChanged\0"
    "on_lineEdit_1_4_textChanged\0"
    "on_lineEdit_2_4_textChanged\0"
    "on_lineEdit_3_4_textChanged\0"
    "on_horizontalSlider_1_sliderMoved\0"
    "position\0on_horizontalSlider_2_sliderMoved\0"
    "on_horizontalSlider_3_sliderMoved\0"
    "on_horizontalSlider_4_sliderMoved\0"
    "on_horizontalSlider_5_sliderMoved\0"
    "on_horizontalSlider_6_sliderMoved\0"
    "on_horizontalSlider_7_sliderMoved\0"
    "on_horizontalSlider_8_sliderMoved\0"
    "on_horizontalSlider_9_sliderMoved\0"
    "on_horizontalSlider_1_4_sliderMoved\0"
    "on_horizontalSlider_2_4_sliderMoved\0"
    "on_horizontalSlider_3_4_sliderMoved"
};
#undef QT_MOC_LITERAL

static const uint qt_meta_data_MainWindow[] = {

 // content:
       8,       // revision
       0,       // classname
       0,    0, // classinfo
      28,   14, // methods
       0,    0, // properties
       0,    0, // enums/sets
       0,    0, // constructors
       0,       // flags
       0,       // signalCount

 // slots: name, argc, parameters, tag, flags
       1,    0,  154,    2, 0x08 /* Private */,
       3,    1,  155,    2, 0x08 /* Private */,
       5,    1,  158,    2, 0x08 /* Private */,
       6,    1,  161,    2, 0x08 /* Private */,
       7,    1,  164,    2, 0x08 /* Private */,
       9,    1,  167,    2, 0x08 /* Private */,
      10,    1,  170,    2, 0x08 /* Private */,
      11,    1,  173,    2, 0x08 /* Private */,
      12,    1,  176,    2, 0x08 /* Private */,
      13,    1,  179,    2, 0x08 /* Private */,
      14,    1,  182,    2, 0x08 /* Private */,
      15,    1,  185,    2, 0x08 /* Private */,
      16,    1,  188,    2, 0x08 /* Private */,
      17,    1,  191,    2, 0x08 /* Private */,
      18,    1,  194,    2, 0x08 /* Private */,
      19,    1,  197,    2, 0x08 /* Private */,
      20,    1,  200,    2, 0x08 /* Private */,
      22,    1,  203,    2, 0x08 /* Private */,
      23,    1,  206,    2, 0x08 /* Private */,
      24,    1,  209,    2, 0x08 /* Private */,
      25,    1,  212,    2, 0x08 /* Private */,
      26,    1,  215,    2, 0x08 /* Private */,
      27,    1,  218,    2, 0x08 /* Private */,
      28,    1,  221,    2, 0x08 /* Private */,
      29,    1,  224,    2, 0x08 /* Private */,
      30,    1,  227,    2, 0x08 /* Private */,
      31,    1,  230,    2, 0x08 /* Private */,
      32,    1,  233,    2, 0x08 /* Private */,

 // slots: parameters
    QMetaType::Void,
    QMetaType::Void, QMetaType::Int,    4,
    QMetaType::Void, QMetaType::Int,    4,
    QMetaType::Void, QMetaType::Int,    4,
    QMetaType::Void, QMetaType::QString,    8,
    QMetaType::Void, QMetaType::QString,    8,
    QMetaType::Void, QMetaType::QString,    8,
    QMetaType::Void, QMetaType::QString,    8,
    QMetaType::Void, QMetaType::QString,    8,
    QMetaType::Void, QMetaType::QString,    8,
    QMetaType::Void, QMetaType::QString,    8,
    QMetaType::Void, QMetaType::QString,    8,
    QMetaType::Void, QMetaType::QString,    8,
    QMetaType::Void, QMetaType::QString,    8,
    QMetaType::Void, QMetaType::QString,    8,
    QMetaType::Void, QMetaType::QString,    8,
    QMetaType::Void, QMetaType::Int,   21,
    QMetaType::Void, QMetaType::Int,   21,
    QMetaType::Void, QMetaType::Int,   21,
    QMetaType::Void, QMetaType::Int,   21,
    QMetaType::Void, QMetaType::Int,   21,
    QMetaType::Void, QMetaType::Int,   21,
    QMetaType::Void, QMetaType::Int,   21,
    QMetaType::Void, QMetaType::Int,   21,
    QMetaType::Void, QMetaType::Int,   21,
    QMetaType::Void, QMetaType::Int,   21,
    QMetaType::Void, QMetaType::Int,   21,
    QMetaType::Void, QMetaType::Int,   21,

       0        // eod
};

void MainWindow::qt_static_metacall(QObject *_o, QMetaObject::Call _c, int _id, void **_a)
{
    if (_c == QMetaObject::InvokeMetaMethod) {
        auto *_t = static_cast<MainWindow *>(_o);
        Q_UNUSED(_t)
        switch (_id) {
        case 0: _t->on_DrawButton_clicked(); break;
        case 1: _t->on_comboBox1_activated((*reinterpret_cast< int(*)>(_a[1]))); break;
        case 2: _t->on_comboBox2_activated((*reinterpret_cast< int(*)>(_a[1]))); break;
        case 3: _t->on_comboBox3_activated((*reinterpret_cast< int(*)>(_a[1]))); break;
        case 4: _t->on_lineEdit_1_textChanged((*reinterpret_cast< const QString(*)>(_a[1]))); break;
        case 5: _t->on_lineEdit_2_textChanged((*reinterpret_cast< const QString(*)>(_a[1]))); break;
        case 6: _t->on_lineEdit_3_textChanged((*reinterpret_cast< const QString(*)>(_a[1]))); break;
        case 7: _t->on_lineEdit_4_textChanged((*reinterpret_cast< const QString(*)>(_a[1]))); break;
        case 8: _t->on_lineEdit_5_textChanged((*reinterpret_cast< const QString(*)>(_a[1]))); break;
        case 9: _t->on_lineEdit_6_textChanged((*reinterpret_cast< const QString(*)>(_a[1]))); break;
        case 10: _t->on_lineEdit_7_textChanged((*reinterpret_cast< const QString(*)>(_a[1]))); break;
        case 11: _t->on_lineEdit_8_textChanged((*reinterpret_cast< const QString(*)>(_a[1]))); break;
        case 12: _t->on_lineEdit_9_textChanged((*reinterpret_cast< const QString(*)>(_a[1]))); break;
        case 13: _t->on_lineEdit_1_4_textChanged((*reinterpret_cast< const QString(*)>(_a[1]))); break;
        case 14: _t->on_lineEdit_2_4_textChanged((*reinterpret_cast< const QString(*)>(_a[1]))); break;
        case 15: _t->on_lineEdit_3_4_textChanged((*reinterpret_cast< const QString(*)>(_a[1]))); break;
        case 16: _t->on_horizontalSlider_1_sliderMoved((*reinterpret_cast< int(*)>(_a[1]))); break;
        case 17: _t->on_horizontalSlider_2_sliderMoved((*reinterpret_cast< int(*)>(_a[1]))); break;
        case 18: _t->on_horizontalSlider_3_sliderMoved((*reinterpret_cast< int(*)>(_a[1]))); break;
        case 19: _t->on_horizontalSlider_4_sliderMoved((*reinterpret_cast< int(*)>(_a[1]))); break;
        case 20: _t->on_horizontalSlider_5_sliderMoved((*reinterpret_cast< int(*)>(_a[1]))); break;
        case 21: _t->on_horizontalSlider_6_sliderMoved((*reinterpret_cast< int(*)>(_a[1]))); break;
        case 22: _t->on_horizontalSlider_7_sliderMoved((*reinterpret_cast< int(*)>(_a[1]))); break;
        case 23: _t->on_horizontalSlider_8_sliderMoved((*reinterpret_cast< int(*)>(_a[1]))); break;
        case 24: _t->on_horizontalSlider_9_sliderMoved((*reinterpret_cast< int(*)>(_a[1]))); break;
        case 25: _t->on_horizontalSlider_1_4_sliderMoved((*reinterpret_cast< int(*)>(_a[1]))); break;
        case 26: _t->on_horizontalSlider_2_4_sliderMoved((*reinterpret_cast< int(*)>(_a[1]))); break;
        case 27: _t->on_horizontalSlider_3_4_sliderMoved((*reinterpret_cast< int(*)>(_a[1]))); break;
        default: ;
        }
    }
}

QT_INIT_METAOBJECT const QMetaObject MainWindow::staticMetaObject = { {
    QMetaObject::SuperData::link<QMainWindow::staticMetaObject>(),
    qt_meta_stringdata_MainWindow.data,
    qt_meta_data_MainWindow,
    qt_static_metacall,
    nullptr,
    nullptr
} };


const QMetaObject *MainWindow::metaObject() const
{
    return QObject::d_ptr->metaObject ? QObject::d_ptr->dynamicMetaObject() : &staticMetaObject;
}

void *MainWindow::qt_metacast(const char *_clname)
{
    if (!_clname) return nullptr;
    if (!strcmp(_clname, qt_meta_stringdata_MainWindow.stringdata0))
        return static_cast<void*>(this);
    return QMainWindow::qt_metacast(_clname);
}

int MainWindow::qt_metacall(QMetaObject::Call _c, int _id, void **_a)
{
    _id = QMainWindow::qt_metacall(_c, _id, _a);
    if (_id < 0)
        return _id;
    if (_c == QMetaObject::InvokeMetaMethod) {
        if (_id < 28)
            qt_static_metacall(this, _c, _id, _a);
        _id -= 28;
    } else if (_c == QMetaObject::RegisterMethodArgumentMetaType) {
        if (_id < 28)
            *reinterpret_cast<int*>(_a[0]) = -1;
        _id -= 28;
    }
    return _id;
}
QT_WARNING_POP
QT_END_MOC_NAMESPACE
